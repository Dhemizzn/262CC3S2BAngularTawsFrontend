
import { Injectable, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { QuoteRequest } from '../model/request/quoteRequest';
import { QuoteResponse } from '../model/response/quoteResponse';
import { environment } from '../components/environments/environment';

@Injectable({ providedIn: 'root' })
export class QuoteService {
  private http = inject(HttpClient);

  private apiUrl = `${environment.url.replace(/\/api\/v1\/?$/, '')}/api/quotations`;

  private _cotizaciones = signal<QuoteResponse[]>([]);
  cotizaciones = this._cotizaciones.asReadonly();

  createQuote(request: QuoteRequest): Observable<QuoteResponse[]> {
    return this.http.post<QuoteResponse[]>(`${this.apiUrl}/generate`, request);
  }

  guardarCotizaciones(cotizaciones: QuoteResponse[]): void {
    this._cotizaciones.set(cotizaciones);
  }
}
