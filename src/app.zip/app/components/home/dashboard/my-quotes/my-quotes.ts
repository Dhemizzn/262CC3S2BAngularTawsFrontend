
import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { QuoteService } from '../../../../services/quote';
import { QuoteResponse } from '../../../../model/response/quoteResponse';

@Component({
  selector: 'app-my-quotes',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './my-quotes.html',
})
export class MyQuotes {
  private quoteService = inject(QuoteService);

  cotizaciones = this.quoteService.cotizaciones;
  detalleSeleccionado: QuoteResponse | null = null;

  verDetalle(cotizacion: QuoteResponse): void {
    this.detalleSeleccionado =
      this.detalleSeleccionado?.proposalId === cotizacion.proposalId
        ? null
        : cotizacion;
  }
}
